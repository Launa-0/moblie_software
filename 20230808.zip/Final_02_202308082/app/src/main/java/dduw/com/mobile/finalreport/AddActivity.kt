package dduw.com.mobile.finalreport

import android.content.ContentValues
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import android.view.MenuItem


class AddActivity : AppCompatActivity() {

    private lateinit var editTitle: EditText
    private lateinit var editAuthor: EditText
    private lateinit var editPublisher: EditText
    private lateinit var editSummary: EditText
    private lateinit var editPrice: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnCancel: Button
    private lateinit var dbHelper: BookDBHelper
    private lateinit var imageSelected: ImageView
    private lateinit var btnSelectImage: Button
    private var selectedImageResId: Int = R.drawable.default_book
    private lateinit var ratingBar: RatingBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        editTitle = findViewById(R.id.editTitle)
        editAuthor = findViewById(R.id.editAuthor)
        editPublisher = findViewById(R.id.editPublisher)
        editSummary = findViewById(R.id.editSummary)
        editPrice = findViewById(R.id.editPrice)
        btnAdd = findViewById(R.id.btnAdd)
        btnCancel = findViewById(R.id.btnCancel)
        imageSelected = findViewById(R.id.imageSelected)
        btnSelectImage = findViewById(R.id.btnChangeImage)
        ratingBar = findViewById(R.id.ratingBar)

        btnSelectImage.setOnClickListener {
            val imageOptions = arrayOf("기본", "어린 왕자", "데미안", "1984", "죄와 벌", "해리포터")
            val imageResIds = arrayOf(
                R.drawable.default_book,
                R.drawable.little_prince,
                R.drawable.demian,
                R.drawable.nineteen_eighty_four,
                R.drawable.crime_and_punishment,
                R.drawable.harry_potter
            )

            AlertDialog.Builder(this)
                .setTitle("표지 이미지 선택")
                .setItems(imageOptions) { _, which ->
                    selectedImageResId = imageResIds[which]
                    imageSelected.setImageResource(selectedImageResId)
                }
                .show()
        }

        dbHelper = BookDBHelper(this)

        btnAdd.setOnClickListener {
                val title = editTitle.text.toString().trim()
                val author = editAuthor.text.toString().trim()
                val publisher = editPublisher.text.toString().trim()
                val summary = editSummary.text.toString().trim()
                val price = editPrice.text.toString().toIntOrNull() ?: 0
                val rating = ratingBar.rating.toInt()

                if (title.isEmpty() || author.isEmpty()) {
                    Toast.makeText(this, "제목과 저자는 필수입니다", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val values = ContentValues().apply {
                    put("title", title)
                    put("author", author)
                    put("publisher", publisher)
                    put("summary", summary)
                    put("price", price)
                    put("imageResId", selectedImageResId)
                    put("rating", rating)
                }

                val db = dbHelper.writableDatabase
                db.insert("books", null, values)
                db.close()

                Toast.makeText(this, "책이 추가되었습니다", Toast.LENGTH_SHORT).show()
                finish()
            }



        }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}

package dduw.com.mobile.finalreport

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.widget.RatingBar


class BookAdapter(
    private var bookList: List<Book>,
    private val onItemClick: (Book) -> Unit,
    private val onItemLongClick: (Book) -> Unit
) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    inner class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleView: TextView = itemView.findViewById(R.id.textTitle)
        val authorView: TextView = itemView.findViewById(R.id.textAuthor)
        val priceView: TextView = itemView.findViewById(R.id.textPrice)
        val coverImageView: ImageView = itemView.findViewById(R.id.imageCover)
        val ratingBar: RatingBar = itemView.findViewById(R.id.ratingBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_book, parent, false)
        return BookViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = bookList[position]
        holder.titleView.text = book.title
        holder.authorView.text = book.author
        holder.priceView.text = "${book.price}원"
        holder.coverImageView.setImageResource(book.imageResId)
        holder.ratingBar.rating = book.rating.toFloat()

        holder.coverImageView.setImageResource(book.imageResId)

        holder.itemView.setOnClickListener {
            onItemClick(book)
        }

        holder.itemView.setOnLongClickListener {
            onItemLongClick(book)
            true
        }

    }

    override fun getItemCount(): Int = bookList.size

    fun updateList(newList: List<Book>) {
        bookList = newList
        notifyDataSetChanged()
    }


}


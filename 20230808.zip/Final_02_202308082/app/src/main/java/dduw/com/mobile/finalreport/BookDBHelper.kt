package dduw.com.mobile.finalreport

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BookDBHelper(context: Context) : SQLiteOpenHelper(context, "books.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE books (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                publisher TEXT,
                summary TEXT,
                price INTEGER,
                imageResId INTEGER,
                rating INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("INSERT INTO books (title, author, publisher, summary, price, imageResId, rating) VALUES ('어린 왕자', '생텍쥐페리', '열린책들', '사막에서 만난 왕자 이야기', 10000, ${R.drawable.little_prince}, 4);")
        db.execSQL("INSERT INTO books (title, author, publisher, summary, price, imageResId, rating) VALUES ('데미안', '헤르만 헤세', '민음사', '자아를 찾아가는 여정', 12000, ${R.drawable.demian}, 5);")
        db.execSQL("INSERT INTO books (title, author, publisher, summary, price, imageResId, rating) VALUES ('1984', '조지 오웰', '한빛미디어', '감시 사회의 경고', 15000, ${R.drawable.nineteen_eighty_four}, 5);")
        db.execSQL("INSERT INTO books (title, author, publisher, summary, price, imageResId, rating) VALUES ('죄와 벌', '도스토예프스키', '더클래식', '살인과 구원의 이야기', 13000, ${R.drawable.crime_and_punishment}, 4);")
        db.execSQL("INSERT INTO books (title, author, publisher, summary, price, imageResId, rating) VALUES ('해리포터', 'J.K. 롤링', '문학수첩', '마법사의 성장기', 11000, ${R.drawable.harry_potter}, 5);")

    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS books")
        onCreate(db)
    }
}

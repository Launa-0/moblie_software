package dduw.com.mobile.finalreport

data class Book(
    val id: Long,
    val title: String,
    val author: String,
    val publisher: String,
    val summary: String,
    val price: Int,
    val imageResId: Int,
    val rating: Int = 0
)

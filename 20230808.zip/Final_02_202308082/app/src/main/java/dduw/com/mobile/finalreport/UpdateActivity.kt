package dduw.com.mobile.finalreport

import android.content.ContentValues
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog


class UpdateActivity : AppCompatActivity() {

    private lateinit var editTitle: EditText
    private lateinit var editAuthor: EditText
    private lateinit var editPublisher: EditText
    private lateinit var editSummary: EditText
    private lateinit var editPrice: EditText
    private lateinit var btnUpdate: Button
    private lateinit var btnCancel: Button
    private lateinit var dbHelper: BookDBHelper
    private lateinit var imageSelected: ImageView
    private lateinit var btnChangeImage: Button
    private lateinit var ratingBar: RatingBar

    private var selectedImageResId: Int = R.drawable.default_book


    private var bookId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        editTitle = findViewById(R.id.editTitle)
        editAuthor = findViewById(R.id.editAuthor)
        editPublisher = findViewById(R.id.editPublisher)
        editSummary = findViewById(R.id.editSummary)
        editPrice = findViewById(R.id.editPrice)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnCancel = findViewById(R.id.btnCancel)
        imageSelected = findViewById(R.id.imageSelected)
        btnChangeImage = findViewById(R.id.btnChangeImage)
        selectedImageResId = intent.getIntExtra("imageResId", R.drawable.default_book)
        imageSelected.setImageResource(selectedImageResId)
        ratingBar = findViewById(R.id.updateRatingBar)


        dbHelper = BookDBHelper(this)

        bookId = intent.getLongExtra("bookId", -1)
        editTitle.setText(intent.getStringExtra("title"))
        editAuthor.setText(intent.getStringExtra("author"))
        editPublisher.setText(intent.getStringExtra("publisher"))
        editSummary.setText(intent.getStringExtra("summary"))
        editPrice.setText(intent.getIntExtra("price", 0).toString())

        val rating = intent.getIntExtra("rating", 0)
        ratingBar.rating = rating.toFloat()


        btnChangeImage.setOnClickListener {
            val imageOptions = arrayOf("기본", "어린 왕자", "데미안", "1984", "죄와 벌", "해리포터")
            val imageResIds = arrayOf(
                R.drawable.default_book,
                R.drawable.little_prince,
                R.drawable.demian,
                R.drawable.nineteen_eighty_four,
                R.drawable.crime_and_punishment,
                R.drawable.harry_potter
            )

            AlertDialog.Builder(this)
                .setTitle("표지 이미지 선택")
                .setItems(imageOptions) { _, which ->
                    selectedImageResId = imageResIds[which]
                    imageSelected.setImageResource(selectedImageResId)
                }
                .show()
        }


        btnUpdate.setOnClickListener {
            val title = editTitle.text.toString().trim()
            val author = editAuthor.text.toString().trim()

            if (title.isEmpty() || author.isEmpty()) {
                Toast.makeText(this, "제목과 저자는 필수입니다", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val publisher = editPublisher.text.toString().trim()
            val summary = editSummary.text.toString().trim()
            val price = editPrice.text.toString().toIntOrNull() ?: 0

            val db = dbHelper.writableDatabase
            val values = ContentValues().apply {
                put("title", title)
                put("author", author)
                put("publisher", publisher)
                put("summary", summary)
                put("price", price)
                put("imageResId", selectedImageResId)
                put("rating", ratingBar.rating.toInt())
            }
            val rating = intent.getIntExtra("rating", 0)
            ratingBar.rating = rating.toFloat()


            db.update("books", values, "_id = ?", arrayOf(bookId.toString()))
            db.close()

            Toast.makeText(this, "수정 완료", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnCancel.setOnClickListener {
            finish()
        }
    }
}

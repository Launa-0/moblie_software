// 과제명: 도서 관리 앱
// 분반: 02 분반
// 학번: 20230808 성명: 오승현
// 제출일: 2025년 6월 26일

package dduw.com.mobile.finalreport

import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView



class MainActivity : AppCompatActivity() {

    private lateinit var bookDBHelper: BookDBHelper
    private lateinit var bookRecyclerView: RecyclerView
    private lateinit var bookAdapter: BookAdapter
    private var bookList: MutableList<Book> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookDBHelper = BookDBHelper(this)

        bookRecyclerView = findViewById(R.id.recyclerViewBooks)
        bookRecyclerView.layoutManager = LinearLayoutManager(this)

        loadBooksFromDB()

        bookAdapter = BookAdapter(bookList,
            onItemClick = { book ->
                val intent = Intent(this, UpdateActivity::class.java).apply {
                    putExtra("bookId", book.id)
                    putExtra("title", book.title)
                    putExtra("author", book.author)
                    putExtra("publisher", book.publisher)
                    putExtra("summary", book.summary)
                    putExtra("price", book.price)
                    putExtra("imageResId", book.imageResId)
                    putExtra("rating", book.rating)
                }
                startActivity(intent)
            },
            onItemLongClick = { book ->
                AlertDialog.Builder(this)
                    .setTitle("삭제 확인")
                    .setMessage("『${book.title}』을(를) 삭제하시겠습니까?")
                    .setPositiveButton("예") { _, _ ->
                        val db = bookDBHelper.writableDatabase
                        db.delete("books", "_id = ?", arrayOf(book.id.toString()))
                        db.close()
                        loadBooksFromDB()
                        bookAdapter.notifyDataSetChanged()
                    }
                    .setNegativeButton("아니오", null)
                    .show()
            }
        )

        bookRecyclerView.adapter = bookAdapter
    }

    private fun loadBooksFromDB() {
        val db = bookDBHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM books", null)

        bookList.clear()

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"))
                val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
                val author = cursor.getString(cursor.getColumnIndexOrThrow("author"))
                val publisher = cursor.getString(cursor.getColumnIndexOrThrow("publisher"))
                val summary = cursor.getString(cursor.getColumnIndexOrThrow("summary"))
                val price = cursor.getInt(cursor.getColumnIndexOrThrow("price"))
                val imageResId = cursor.getInt(cursor.getColumnIndexOrThrow("imageResId"))
                val rating = cursor.getInt(cursor.getColumnIndexOrThrow("rating"))

                val book = Book(id, title, author, publisher, summary, price, imageResId, rating)
                bookList.add(book)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
    }


    private var searchItem: MenuItem? = null
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)

        searchItem = menu?.findItem(R.id.action_search)
        val searchView = searchItem?.actionView as? SearchView
        searchItem = menu?.findItem(R.id.action_search)

        searchView?.queryHint = "책 제목 또는 저자 검색"
        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = true

            override fun onQueryTextChange(newText: String?): Boolean {
                filterBookList(newText.orEmpty())
                return true
            }
        })

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_add_text -> {
                val intent = Intent(this, AddActivity::class.java)
                startActivity(intent)
                true
            }

            R.id.menu_search_text -> {

                searchItem?.expandActionView()
                searchItem?.expandActionView()
                true
            }

            R.id.menu_add -> {
                val intent = Intent(this, AddActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.menu_developer -> {
                val intent = Intent(this, DeveloperActivity::class.java)
                startActivity(intent)
                true
            }

            R.id.menu_exit -> {
                showExitDialog()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        loadBooksFromDB()
        bookAdapter.notifyDataSetChanged()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("앱 종료")
            .setMessage("앱을 종료하시겠습니까?")
            .setPositiveButton("예") { _, _ -> finish() }
            .setNegativeButton("아니오", null)
            .show()
    }

    private fun filterBookList(query: String) {
        val filteredList = bookList.filter {
            it.title.contains(query, ignoreCase = true) ||
                    it.author.contains(query, ignoreCase = true)
        }
        bookAdapter.updateList(filteredList)
    }


}

